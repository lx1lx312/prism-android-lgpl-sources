#ifndef CAMLIBS_AX203_JPEG_MEMSRCDEST_H
#define CAMLIBS_AX203_JPEG_MEMSRCDEST_H

#include <jpeglib.h>

#if JPEG_LIB_VERSION < 80 && !defined(MEM_SRCDST_SUPPORTED)

#define JPEG_SIZE unsigned long

void
jpeg_mem_src (j_decompress_ptr cinfo, unsigned char * buffer,
	unsigned long bufsize);

void
jpeg_mem_dest (j_compress_ptr cinfo, unsigned char ** outbuffer,
	unsigned long * outsize);

#endif

#endif /* !defined(CAMLIBS_AX203_JPEG_MEMSRCDEST_H) */
